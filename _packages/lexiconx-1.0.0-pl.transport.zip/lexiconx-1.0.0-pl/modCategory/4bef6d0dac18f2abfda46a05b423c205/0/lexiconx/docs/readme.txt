LexiconX for MODX
============
Tiny custom lexicon for MODx Revolution includes essential words and phrases .) (alpha)

See more: https://github.com/bartholomej/modx-essential-lexicon